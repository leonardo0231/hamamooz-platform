from django.apps import AppConfig


class AccountsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "hamamooz.apps.accounts"
    verbose_name = "کاربران و دسترسی"
